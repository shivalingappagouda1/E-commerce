#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';

const root = path.resolve(process.argv[2] ?? process.cwd());
const files = {
  migration: 'database/migrations/phase9_security_hardening_corrected.sql',
  verification: 'database/tests/phase9_security_verification.sql',
  export: 'database/tests/phase9_pre_migration_export.sql',
  rollback: 'database/migrations/phase9_rollback.sql',
  report: 'database/tests/phase9_1_migration_safety_review.md',
};
const failures = [];
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
for (const [name, p] of Object.entries(files)) {
  if (!fs.existsSync(path.join(root, p))) failures.push(`Missing ${name}: ${p}`);
}
const validatorPath = path.join(root, 'test_phase9_validation.mjs');
if (!fs.existsSync(validatorPath)) failures.push('Missing validator: test_phase9_validation.mjs');
if (failures.length) { console.error(failures.join('\n')); process.exit(1); }

const migration = read(files.migration);
const migrationCode = migration.replace(/--[^\n]*/g, '');
const verification = read(files.verification);
const verificationCode = verification.replace(/--[^\n]*/g, '');
const rollback = read(files.rollback);
const rollbackCode = rollback.replace(/--[^\n]*/g, '');
const exportSql = read(files.export);
const exportCode = exportSql.replace(/--[^\n]*/g, '');
const report = read(files.report);

const names = [
  ['categories','Admins full access to categories'],
  ['products','Admins full access to products'],
  ['product_images','Admins full access to product images'],
  ['product_variants','Admins full access to product variants'],
  ['inventory','Admins full access to inventory'],
  ['coupons','Admins full access to coupons'],
  ['banners','Admins full access to banners'],
  ['reviews','Admins full access to reviews'],
];

const tests = [];
const check = (name, ok, detail='') => tests.push({name,ok,detail});

check('Migration has one explicit transaction', /^BEGIN;[\s\S]*COMMIT;\s*$/m.test(migration));
check('Migration alters exactly the eight reviewed existing policies', names.every(([t,n]) => migration.includes(`ALTER POLICY "${n}" ON public.${t} TO authenticated`)) && (migration.match(/ALTER POLICY /g)||[]).length===8);
check('Migration does not create or drop policies', !/\b(CREATE|DROP)\s+POLICY\b/i.test(migrationCode));
check('Migration checks authenticated role in pg_roles and avoids pseudo-role public in pg_roles',
  /rolname\s*=\s*'authenticated'/.test(migrationCode) && !/rolname\s*=\s*'public'/.test(migrationCode)
);
check('Migration preflight verifies original public role and is_admin predicates', migration.includes("ARRAY['public']::text[]") && migration.includes("'is_admin'") && migration.includes("'public.is_admin'"));
check('Migration postflight verifies authenticated role on all eight policies', migration.includes("ARRAY['authenticated']::text[]") && migration.includes('Phase 9.1 complete'));
check('Migration verifies table RLS and FORCE RLS state', migration.includes('relrowsecurity') && migration.includes('relforcerowsecurity'));
check('Migration verifies authenticated is_admin execute privilege', migration.includes("has_function_privilege('authenticated'"));
check('Migration does not alter Storage, functions, grants, triggers, or data', !/storage\.|\b(REVOKE|GRANT|ALTER\s+FUNCTION|CREATE\s+OR\s+REPLACE\s+FUNCTION|INSERT\s+INTO|UPDATE\s+\w+\s+SET|DELETE\s+FROM)\b/i.test(migrationCode));

check('Verification checks all eight original policy names and authenticated roles', names.every(([t,n]) => verification.includes(`'${t}','${n}'`)) && verification.includes("ARRAY['authenticated']::text[]"));
check('Verification SQL marks customer/storage/function/trigger review manual', ['CUSTOMER-POLICIES','STORAGE-POLICIES','FUNCTIONS','TRIGGERS'].every(x=>verification.includes(x)) && verification.includes('NEEDS MANUAL REVIEW'));
check('Verification SQL is read-only', !/\b(INSERT\s+INTO|UPDATE\s+\w+\s+SET|DELETE\s+FROM|CREATE\s+TEMP|TRUNCATE|ALTER\s+POLICY)\b/i.test(verificationCode));

check('Export SQL covers all six required sections',
  ['1.', '2.', '3.', '4.', '5.', '6.'].every(s => exportSql.includes(s)) &&
  exportSql.includes('pg_policies') && exportSql.includes('relrowsecurity') &&
  exportSql.includes('storage.buckets') && exportSql.includes('prosecdef') &&
  exportSql.includes('pg_get_triggerdef') && exportSql.includes('is_admin')
);
check('Export SQL is read-only', !/\b(INSERT\s+INTO|UPDATE\s+\w+\s+SET|DELETE\s+FROM|CREATE\s+TEMP|TRUNCATE|ALTER\s+POLICY)\b/i.test(exportCode));

check('Rollback has one explicit transaction', /^BEGIN;[\s\S]*COMMIT;\s*$/m.test(rollback));
check('Rollback alters only eight policies to the original public role', names.every(([t,n]) => rollback.includes(`ALTER POLICY "${n}" ON public.${t} TO public`)) && (rollback.match(/ALTER POLICY /g)||[]).length===8);
check('Rollback does not create or drop policies', !/\b(CREATE|DROP)\s+POLICY\b/i.test(rollbackCode));
check('Rollback guards the authenticated post-migration definitions', rollback.includes("ARRAY['authenticated']::text[]") && rollback.includes('ROLLBACK ABORT'));

check('Report documents the observed CSV baseline and staging-only restrictions', report.includes('19 admin-related policies') && report.includes('ShopKart-Staging') && report.includes('No SQL was executed'));

const reportsReportPath = path.join(root, 'reports/phase9_1_migration_safety_review.md');
if (fs.existsSync(reportsReportPath)) {
  const reportsReport = fs.readFileSync(reportsReportPath, 'utf8');
  check('Safety review reports are synchronized across database/tests and reports directories', report === reportsReport);
}

for (const t of tests) console.log(`${t.ok?'PASS':'FAIL'}  ${t.name}${t.detail?` — ${t.detail}`:''}`);
const failed = tests.filter(t=>!t.ok).length;
console.log(`\n${tests.length-failed}/${tests.length} static checks passed.`);
if (failed) process.exit(1);
console.log('LIMITATION: static checks do not parse PostgreSQL or prove live database behavior.');
