# ShopKart — Phase 6C Final Corrections Dossier (Deterministic Restocking & Reconciled Audit)

> [!CAUTION]
> **Phase 6C status: NOT APPROVED.**
> This document records all corrections implemented across the migration, frontend checkout lifecycle, admin services, test suite, and concurrency test runner.
> Final approval is reserved exclusively for the system owner after independent evaluation.
> **Zero SQL has been executed against Supabase. No remote database or credentials have been touched.**

---

## 1. Executive Status & Metrics

| Component | Status | Details |
|---|---|---|
| **Deterministic Restocking Engine** | ✅ **CORRECTED** | `_restock_approved_return_inspections` locks eligible inspections via `FOR UPDATE` (`ORDER BY pri.id ASC`), filters `receipt_confirmed = TRUE`, tracks exact locked IDs, aggregates with `ORDER BY pri.product_id, pri.variant_id`, and marks strictly processed rows |
| **Option B Physical Return Architecture** | ✅ **IMPLEMENTED** | `physical_return_inspections` table, `chk_outcome_qty` constraint, `admin_create_return_inspection` with `order_items` `FOR UPDATE` lock, `admin_complete_return_inspection` |
| **PhonePe Expiry Hardening** | ✅ **IMPLEMENTED** | `expire_pending_phonepe_orders()` revoked from PUBLIC/anon/authenticated, granted strictly to `service_role` with internal `is_admin()` check |
| **PGlite Embedded Test Suite** | ✅ **182/182 PASS** | 182 verified assertions across 22 categories in embedded PostgreSQL 17.5 WASM (0 failures). Sum of all categories strictly equals 182 |
| **Frontend Checkout Idempotency** | ✅ **IMPLEMENTED** | Deterministic sorting (`productId:variantId:qty`), `{ fingerprint, idempotencyKey }` in `sessionStorage`, `useRef` synchronous double-click lock, key retained across failures, cleared only on confirmed success |
| **Admin Service Integration** | ✅ **IMPLEMENTED** | Standardized 4-argument `adminRecordRefund`, `adminCompleteReturnInspection` supporting `passed`, `partially_passed`, and `rejected` |
| **Rollback Script Synchronization** | ✅ **UPDATED** | `phase6c_rollback.sql` drops `_restock_approved_return_inspections(UUID)` |
| **PostgreSQL Concurrency Test Runner** | ⚠️ **STANDBY / UNVERIFIED** | Tests A–H implemented (including Test H: multi-connection concurrent restocking race); strict safety gate requiring `shopkart_test` on `127.0.0.1`/`localhost`; TCP connect to port 5432 failed (`connect EACCES 127.0.0.1:5432` — no local daemon listening) |
| **Frontend Production Build** | ✅ **PASS** | `npm run build` succeeds in 2.02s (2,167 modules transformed, 0 build errors) |
| **Supabase Remote Execution** | ⛔ **BLOCKED** | Migration intentionally withheld pending local PostgreSQL concurrency verification and owner sign-off |

---

## 2. Corrected Shared Restocking Engine (`_restock_approved_return_inspections`)

### Root Cause of Concurrency Vulnerability
In the earlier revision, `_restock_approved_return_inspections` executed an aggregate query without `FOR UPDATE`. Because PostgreSQL does not support `FOR UPDATE` with aggregate expressions (`GROUP BY`), inspection rows were not locked prior to inventory updates. Two simultaneous calls could read `restocked = FALSE`, both increment inventory, and both mark rows restocked (double restocking).

### Corrective Implementation
The helper follows a strict four-phase atomic pattern:
1. **Deterministic Row-Level Locking (`FOR UPDATE`)**:
   Selects un-restocked inspections with `ORDER BY pri.id ASC` (preventing deadlocks) and acquires row-level locks before reading or aggregating quantities. Only rows with `receipt_confirmed = TRUE`, `inspection_outcome IN ('passed', 'partially_passed')`, `approved_quantity > 0`, and `restocked = FALSE` are locked.
   In PostgreSQL Read Committed mode, if a concurrent transaction commits `restocked = TRUE` while another is waiting for the lock, once the lock is acquired the row is re-evaluated and skipped.
2. **Exact Locked ID Tracking**:
   Appends locked primary keys to `v_locked_ids UUID[]`. If no rows are locked, returns `0` immediately without modifying inventory.
3. **Deterministic Aggregation & Inventory Restoration**:
   Aggregates quantities strictly matching `WHERE pri.id = ANY(v_locked_ids)` with deterministic ordering:
   `ORDER BY pri.product_id, pri.variant_id`
   This eliminates lock-order inversions and deadlocks across concurrent orders that share products.
   Updates inventory with row count verification (rolling back on missing product rows).
4. **Exact Row Marking**:
   Marks strictly `WHERE id = ANY(v_locked_ids)` as `restocked = TRUE`, leaving unprocessed or concurrent inspections completely untouched.

```sql
CREATE OR REPLACE FUNCTION public._restock_approved_return_inspections(
  p_order_id UUID
)
RETURNS INT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_locked_rec RECORD;
  v_locked_ids UUID[] := ARRAY[]::UUID[];
  v_item RECORD;
  v_rows_updated INT;
  v_total_restocked INT := 0;
BEGIN
  IF p_order_id IS NULL THEN
    RAISE EXCEPTION 'Order ID is required for restocking approved inspections';
  END IF;

  -- 1. Deterministically lock eligible, un-restocked inspections using FOR UPDATE
  FOR v_locked_rec IN
    SELECT pri.id, pri.product_id, pri.variant_id, pri.approved_quantity
    FROM public.physical_return_inspections pri
    WHERE pri.order_id = p_order_id
      AND pri.receipt_confirmed = TRUE
      AND pri.inspection_outcome IN ('passed', 'partially_passed')
      AND pri.approved_quantity > 0
      AND pri.restocked = FALSE
    ORDER BY pri.id ASC
    FOR UPDATE
  LOOP
    v_locked_ids := array_append(v_locked_ids, v_locked_rec.id);
  END LOOP;

  -- If no un-restocked inspections were locked by this transaction, return 0 immediately
  IF array_length(v_locked_ids, 1) IS NULL OR array_length(v_locked_ids, 1) = 0 THEN
    RETURN 0;
  END IF;

  -- 2. Aggregate quantities ONLY across the exact locked inspection IDs with deterministic ordering
  FOR v_item IN
    SELECT pri.product_id, pri.variant_id, SUM(pri.approved_quantity)::int AS quantity
    FROM public.physical_return_inspections pri
    WHERE pri.id = ANY(v_locked_ids)
    GROUP BY pri.product_id, pri.variant_id
    ORDER BY pri.product_id, pri.variant_id
  LOOP
    UPDATE public.inventory
    SET quantity = quantity + v_item.quantity,
        updated_at = NOW()
    WHERE product_id = v_item.product_id
      AND variant_id IS NOT DISTINCT FROM v_item.variant_id;

    GET DIAGNOSTICS v_rows_updated = ROW_COUNT;
    IF v_rows_updated = 0 THEN
      RAISE EXCEPTION 'Inventory record missing for product %; restocking transaction rolled back', v_item.product_id;
    END IF;

    v_total_restocked := v_total_restocked + v_item.quantity;
  END LOOP;

  -- 3. Mark strictly the exact locked inspection IDs as restocked
  UPDATE public.physical_return_inspections
  SET restocked = TRUE,
      restocked_at = NOW(),
      updated_at = NOW()
  WHERE id = ANY(v_locked_ids);

  RETURN v_total_restocked;
END;
$$;

REVOKE ALL ON FUNCTION public._restock_approved_return_inspections(UUID) FROM PUBLIC;
REVOKE ALL ON FUNCTION public._restock_approved_return_inspections(UUID) FROM anon;
REVOKE ALL ON FUNCTION public._restock_approved_return_inspections(UUID) FROM authenticated;
GRANT EXECUTE ON FUNCTION public._restock_approved_return_inspections(UUID) TO service_role;
```

---

## 3. Reconciled PGlite Category Breakdown (182 Total)

Every assertion logged to `public._phase6c_test_log` has been queried and reconciled. The 22 categories sum exactly to **182**:

| Category | Assertions | Test ID Range | Description |
|---|---|---|---|
| **Schema** | 5 | 1–5 | Column existence (`idempotency_key`, `refund_reference`, `payment_submissions` schema) |
| **Security** | 31 | 6–36 | RLS & FORCE RLS, SECURITY DEFINER, strict empty `search_path=""` across all functions, regproc overload checks |
| **Privileges** | 34 | 37–70 | Strict verification: PUBLIC & anon revoked across all 11 functions; client RPCs granted to authenticated; internal/service RPCs granted to `service_role` |
| **RLS Enforcement** | 7 | 71–77 | Customer data isolation: user 2 blocked from user 1 orders, payments, submissions; admin bypass verified |
| **Inventory** | 5 | 78, 85–88 | Atomic stock deduction, row-level `FOR UPDATE` lock verification, overselling rejection |
| **Checkout** | 2 | 79, 81 | Delivery address ownership validation, empty cart rejection |
| **Shipping** | 1 | 80 | Server-side shipping fee calculation (₹99 below ₹999; free at ₹999+) |
| **Payment** | 3 | 82–84 | Payment provider validation (`cod`, `phonepe`), initial pending status creation |
| **Idempotency** | 10 | 89–98 | Same-key duplicate order prevention, single inventory deduction, cart-lock recheck, single payment record |
| **UTR Submission** | 4 | 99–102 | Customer PhonePe UTR submission, database `NOW()` timestamp enforcement, duplicate pending submission rejection |
| **Authorization** | 4 | 103–106 | Customer blocked from `admin_verify_utr`, `admin_confirm_cod_payment`, `admin_record_refund`, and `expire_pending_phonepe_orders` |
| **Admin Verification** | 7 | 107–109, 121–124 | Admin approval/rejection transitions, `paid_at` timestamp population, payment `completed` transition |
| **PhonePe Lifecycle** | 2 | 110, 112 | Historical UTR audit logging, 48-hour window preserved relative to database `created_at` |
| **UTR Resubmission** | 2 | 111, 113 | Resubmission after rejection without restocking inventory, historical submissions preserved |
| **PhonePe Expiry** | 7 | 114–120 | Expiry at 48h boundary; orders with submitted UTR do not expire; caller-controlled timestamp overload rejected |
| **Cancellation** | 6 | 125–127, 132–134 | Paid processing cancellation does NOT restore stock; unpaid pending cancellation restores stock exactly once; duplicate cancellation rejected |
| **Order Lifecycle** | 4 | 128–131 | Cancelled order blocked from reopening to `pending`, `processing`, `shipped`, or `delivered` |
| **Refunds** | 17 | 135–151 | Refund reference required, inspection notes required, non-completed payment blocked, exact stock restoration, duplicate refund rejected, missing inventory rollback |
| **Shipping Matrix** | 4 | 152–155 | Exact ₹999 boundary tested, gross subtotal discount immunity, free shipping threshold verification |
| **COD Collection** | 3 | 156–158 | COD collection blocked prior to delivery, payment transitions to completed upon delivery confirmation |
| **Physical Returns** | 18 | 159–167, 174–182 | Cumulative return quantity enforcement, partial returns restore approved count (+1), duplicate restocking blocked, rejected return blocked, unconfirmed receipt (`receipt_confirmed=false`) skipped, exact ID marking |
| **Constraints** | 6 | 168–173 | Table constraint `chk_outcome_qty` validation for `pending`, `rejected`, `passed`, and `partially_passed` states |
| **TOTAL** | **182** | **1–182** | **182 Passed, 0 Failed** |

---

## 4. Concurrency Test Runner Status (`test_true_concurrent_connections.mjs`)

Includes **Test H (True Multi-Connection Concurrent Restocking Race)**:
- Two independent TCP client sessions simultaneously invoke `_restock_approved_return_inspections(order_id)` on the exact same order.
- Asserts that:
  - Exactly one session restocks 2 units; the other returns 0 units.
  - Total physical inventory increases by exactly 2 (double restocking prevented).
  - Return inspection row is marked `restocked = TRUE` exactly once.

**Actual Host Execution Output**:
```text
=================================================================
SHOPKART: TRUE MULTI-CONNECTION POSTGRESQL CONCURRENCY TEST
Testing two independent TCP client sessions with real row-level locks
Target Server: postgres://postgres:postgres@127.0.0.1:5432/shopkart_test
=================================================================

✔ Target safety gate passed: Target is verified local loopback test database (not Supabase).
Connecting Client 1 and Client 2 to postgres://postgres:postgres@127.0.0.1:5432/shopkart_test...
-----------------------------------------------------------------
REAL POSTGRESQL CONCURRENCY TESTS: NOT EXECUTED
STATUS: UNVERIFIED ON THIS HOST (LOCAL POSTGRESQL SERVER INACTIVE)
Reason: TCP connection to 127.0.0.1:5432 failed (connect EACCES 127.0.0.1:5432)
No local PostgreSQL daemon or Docker container is currently listening on port 5432.

To execute this test in an isolated local environment:
  1. docker run --name shopkart-pg -e POSTGRES_PASSWORD=postgres -p 5432:5432 -d postgres:17
  2. psql -h 127.0.0.1 -U postgres -c "CREATE DATABASE shopkart_test;"
  3. $env:PG_CONNECTION_STRING="postgres://postgres:postgres@127.0.0.1:5432/shopkart_test"
  4. node scratch/test_true_concurrent_connections.mjs
-----------------------------------------------------------------
```

---

## 5. Deliverables Package

A comprehensive ZIP bundle `ShopKart_Phase6C_Final_Verification_Source.zip` has been prepared in the repository root containing all 8 complete files.
